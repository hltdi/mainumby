"""Mainumby morphology."""

__all__ = ['fs', 'fst', 'internals', 'logic', 'morpho', 'semiring', 'strip', 'utils']

from .morpho import *



